public interface ProxyInterface {

    void setName(String name);
    
}
