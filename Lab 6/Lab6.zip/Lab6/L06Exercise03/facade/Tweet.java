
public class Tweet {

    private String tweet; 

    public Tweet(String tweet)
    {
        this.tweet = tweet; 
    }

    public String getTweet(){

        return tweet; 
    }

}
